<?
    $Login = $_POST['login'];
    $Password = $_POST['password'];
    $LoginAndPassword = file("users/$Login.txt");
    $Password1 = $LoginAndPassword[1];
    if ($Password == $Password1) {
        echo 'OK';
    } else {
        echo 'Неверный логин или пароль';
    }
?>