<?
    $Login = $_POST['login'];
    $Password = $_POST['password'];
    file_put_contents("users/$Login.txt", "$Login\n$Password");
    echo 'Регистрация прошла успешно!';
?>